// app/api/research/route.js

import { streamText } from "ai";
import { google } from "@ai-sdk/google";
import { agent } from "../../../lib/agents";


export async function POST(req) {
  try {
    
    const { messages } = await req.json();

    const userQuery = messages[messages.length - 1].content;

    const context = await agent(userQuery);

    const result = await streamText({
      model: google("gemini-1.5-flash"),
      messages: [
        {
          role: "system",
          content: `
You are an AI assistant.

Use clean formatting with headings and bullets.
Context:
${context}
          `,
        },
        ...messages,
      ],
    });

    return result.toAIStreamResponse();

  } catch (error) {
    console.error(error);
    return new Response("Error", { status: 500 });
  }
}